# Multi Role Review Protocol

所有重要方案讨论必须输出：

1. 各角色观点
2. 冲突点
3. 风险
4. ARCH最终裁决

角色按问题启用：
- Algorithm Engineer
- Google Quality Engineer
- Apple Engineer
- Apple UX Engineer
- Google UI Engineer
- UI Engineer
- ARCH
