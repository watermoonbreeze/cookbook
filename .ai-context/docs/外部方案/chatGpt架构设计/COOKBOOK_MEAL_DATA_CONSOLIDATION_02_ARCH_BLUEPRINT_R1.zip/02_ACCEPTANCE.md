# Acceptance

检查：
- Truth / Read Projection / Feature State 分层明确
- DayMealCardData 不污染 Feature 专属语义
- Nutrition 不反向污染 Meal Projection
- Home/Timeline/Search 不绕过统一链路
- 文档和测试完成
