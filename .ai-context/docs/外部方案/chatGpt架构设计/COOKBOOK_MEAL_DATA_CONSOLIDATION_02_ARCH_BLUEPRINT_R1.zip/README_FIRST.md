# MEAL-DATA-CONSOLIDATION-02 ARCH BLUEPRINT R1

执行入口：README_FIRST.md

目标：
Projection Boundary Refinement。

核心决策：
保持 MealDayContent -> MealDayCardProjector -> DayMealCardData 主链，
不进行大规模 Projection 拆分。

禁止：
- 新增 MealPlan 持久化
- 数据库迁移
- Repository 大拆分
- Feature 无边界扩张

后续 ARCH 讨论采用多角色评审：

算法/数据类：
- 算法工程师：算法正确性、数据语义、复杂度
- Google质量工程师：测试、可靠性、边界条件
- Apple工程师：系统设计、生命周期、用户体验影响

界面/交互类：
- Apple UX 工程师：交互一致性、用户心智、信息架构
- Google UI 工程师：平台规范、组件设计、实现约束
- 界面工程师：组件复用、工程落地

ARCH负责最终裁决。
Coder只执行冻结方案。
