# Scope

允许：
- 固化 Projection Contract
- 明确 Repository API 分级
- 增加边界测试
- 更新治理文档

禁止：
- 新增领域实体
- 改用户行为
- 重构无关Feature
