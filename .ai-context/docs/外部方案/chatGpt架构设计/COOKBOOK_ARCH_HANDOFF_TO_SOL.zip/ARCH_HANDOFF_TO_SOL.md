# CookBook ARCH Handoff To Local SOL Model

## Repository

URL:
https://github.com/watermoonbreeze/cookbook

Git:
https://github.com/watermoonbreeze/cookbook.git

---

# Current Execution State

Workflow:

ARCH Design
-> Blueprint Package
-> Luna/Coder Execution
-> Commit
-> ARCH Review

---

# Completed Milestones

## MDC3

Status:
- Code complete
- AppLogger unified
- Blueprint preparation complete

Important commits:

3e08140
- MDC3-R3 AppLogger unified sink

3bffb063
- MDC3 close preparation
- Foundation Observability blueprint preparation

6a9a76c
- Foundation Observability executable code blueprint frozen

---

# Current Blocker

MDC3 Device Evidence

State:
PENDING

Important:
真机验证最后统一执行，不阻断架构推进。

Required cases:

1. meal_record_dish
2. dish
3. dish_ingredient

Evidence:

AppLogger exported file logs

Expected chain:

Revision
-> Projection
-> UI

---

# Foundation Observability-01

Current:

ARCH Blueprint: COMPLETE

CODE Blueprint: COMPLETE

Implementation: NOT STARTED


Next implementation scope:

1. LogLevel

2. Logger facade

3. TraceModel

Including:

- TraceId
- OperationTrace
- UIStateTrace
- DataFlowTrace
- PerformanceTrace


4. KMP boundary

commonMain:
models/interfaces

androidMain:
adapter

androidApp:
AppLogger sink


---

# Hard Architecture Rules

All application logs MUST go through AppLogger.

Required:

Application
 -> AppLogger
 -> logcat + debug local file


Forbidden:

- direct application android.util.Log
- independent logger
- second logging path


---

# Implementation Boundary

Allowed:

- LogLevel
- TraceModel
- Logger facade
- Android adapter
- AppLogger structured event support


Forbidden:

- business logic changes
- database/schema changes
- Repository semantic changes
- full project migration
- UI business modification


---

# BLUEPRINT_STATE

Current expected:

Foundation Observability:
BLUEPRINT_READY / PENDING ARCH REVIEW

TURN:
REVIEW

Holder:
ARCH


MDC3:
CODE_COMPLETE / PENDING DEVICE EVIDENCE


Do not mark ACCEPTED/CLOSED before runtime evidence review.

---

# Review Method

For every commit:

Check:

1. Diff
2. Blueprint compliance
3. Boundary
4. BLUEPRINT_STATE
5. Evidence
6. Hidden business changes


Output:

ACCEPT or REWORK

Then generate next blueprint task.

---

# Multi Role Review

Required:

Algorithm Engineer:
data flow and diagnostics

Google Quality Engineer:
testing and evidence

Apple Engineer:
lifecycle/state

Apple UX Engineer:
user behavior tracing

Google UI Engineer:
UI state

UI Engineer:
implementation cost

ARCH:
final decision


---

# Next Recommended Task

FOUNDATION-OBSERVABILITY-01-IMPLEMENTATION-R1

Implement only:

- LogLevel
- TraceModel
- Logger facade
- Android adapter
- AppLogger integration

Then ARCH review.

Finally perform MDC3 device evidence.
