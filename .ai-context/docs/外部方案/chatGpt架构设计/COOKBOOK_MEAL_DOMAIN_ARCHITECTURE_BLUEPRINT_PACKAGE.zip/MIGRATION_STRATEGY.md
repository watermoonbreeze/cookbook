# Migration Strategy

## Phase 1

新增 Canonical Meal Model。

## Phase 2

增加 Legacy Adapter。

## Phase 3

业务逐步迁移。

## Phase 4

删除旧模型。

原则：

可回滚。

不破坏已有用户流程。

禁止：

直接删除旧模型。
