# Implementation Guide For Coder

执行原则：

1.  不改变冻结契约。
2.  不自行重新设计 Domain。
3.  所有实现必须映射 Blueprint。
4.  先添加模型，再迁移调用。
5.  每一步提供 Evidence。

允许：

-   类名调整
-   包结构优化
-   测试补充

禁止：

-   修改推荐算法
-   修改数据库核心结构
-   绕过 Domain
-   创建第二套 Meal Truth
