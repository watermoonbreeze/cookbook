# Boundary Contract

## Domain Contract

Domain 保存业务事实。

## Projection Contract

Projection 只读展示。

## Repository Contract

Repository 不承载领域规则。

## AI Contract

AI 是能力提供方。

不是领域拥有者。

## Trace Contract

Domain Event 可以转换为 Structured Trace Event。

用于诊断和审计。
