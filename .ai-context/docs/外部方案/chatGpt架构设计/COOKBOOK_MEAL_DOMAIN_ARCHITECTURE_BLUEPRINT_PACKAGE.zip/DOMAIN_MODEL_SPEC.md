# Domain Model Specification

## Meal

Aggregate Root。

字段概念：

MealId

LifecycleState

MealContent

MealOccurrence

MealSource

MealMetadata

## MealId

唯一稳定身份。

## MealOccurrence

表示：

日期

餐别

发生上下文。

## MealSource

来源：

MANUAL

AI_GENERATED

IMPORTED

SYSTEM_TEMPLATE

## Nutrition

使用 Snapshot。

历史数据不可被未来计算覆盖。

## Metadata

用于：

Trace

Audit

Analytics

不参与业务判断。
