# Meal Lifecycle Specification

## State Flow

CREATED

↓

DRAFT

↓

READY

↓

SAVED

↓

MODIFIED

↓

READY

最终：

SAVED

↓

ARCHIVED

异常：

FAILED

## Rules

禁止：

ARCHIVED -\> DRAFT

SAVED -\> CREATED

Projection -\> State Change

AI -\> State Change

状态拥有者：

Meal Domain
