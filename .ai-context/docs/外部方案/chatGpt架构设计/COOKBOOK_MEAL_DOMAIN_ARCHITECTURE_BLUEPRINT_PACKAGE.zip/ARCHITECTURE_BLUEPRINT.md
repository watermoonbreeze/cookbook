# CookBook Meal Domain Architecture Blueprint

## 1. Architecture Goal

建立 Canonical Meal Domain Model。

解决： - 今日餐 - 计划餐 - 历史餐 - 草稿餐 - AI生成餐

多个模型导致的语义漂移。

核心原则：

Meal Domain 是唯一事实来源。

Projection 只能展示。

AI 只能提供能力。

Repository 不拥有业务规则。

## 2. Target Architecture

UI

↓

Projection Layer

↓

Meal Domain Layer

↓

Repository

↓

Data Layer

## 3. Aggregate Boundary

Aggregate Root:

Meal

包含：

-   Identity
-   Lifecycle
-   Content
-   Context
-   Source
-   Metadata
-   Relations

Recipe、Ingredient、Nutrition 不作为 Root。

## 4. Identity

冻结：

MealId 是唯一身份。

MealOccurrence 表示发生时间。

Meal 与 Occurrence 分离。

## 5. Lifecycle

状态：

CREATED

DRAFT

READY

SAVED

MODIFIED

FAILED

ARCHIVED

Lifecycle 所属：

Meal Domain

禁止：

UI 修改状态

Projection 修改状态

AI 修改状态

## 6. Projection

建立：

Home Projection

Timeline Projection

History Projection

Edit Projection

Projection:

不是事实源。

不能创建 Meal Identity。

## 7. Repository Boundary

Repository:

负责：

-   load
-   save
-   query

禁止：

-   状态迁移
-   业务决策
-   AI逻辑
-   Projection生成

## 8. AI Boundary

AI 输出：

Suggestion

Reason

Feedback

必须经过：

Validation

↓

Meal Domain

↓

Saved Meal

AI 不直接创建 Domain Truth。

## 9. Migration

采用 Adapter Strategy。

Old Model

↓

Adapter

↓

Canonical Meal

禁止一次性重构。
