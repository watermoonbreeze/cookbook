# FOUNDATION OBSERVABILITY + UBF ARCHITECTURE DESIGN

版本：
2026-08

用途：
提供给本地 ARCH/分析模型，用于对照当前项目全景图、功能地图、代码结构进行架构梳理。

---

# 一、背景

当前项目已经建立 UBF(Blueprint) 架构流程：

需求/问题
    ↓
ARCH 多角色分析
    ↓
Current State Model
    ↓
Architecture Decision
    ↓
Blueprint
    ↓
Coder执行
    ↓
Evidence Review

但是存在两个限制：

1. 在线 ARCH 无法持续实时观察整个项目全景。
2. 单纯代码审核无法覆盖运行时行为。

因此增加：

Foundation Observability Framework。

目标：

让项目同时具备：

- 静态架构可理解性
- 动态运行可观测性
- 真机问题可复现性


---

# 二、总体架构

整体分层：

Application

    |
    + UI Layer
    |
    + Domain Layer
    |
    + Data Layer
    |
    + Infrastructure


横向能力：

                Observability Framework

                        |
        +---------------+---------------+
        |               |               |
    Operation       UI State        Data Flow
      Trace           Trace           Trace

                        |
                Performance Trace

                        |
                Logger Core

                        |
        +---------------+---------------+
        |                               |
      Debug                         Release

全部输出                    Error + Important


---

# 三、日志分类设计


## 1. Operation Trace 操作路由

目的：

回答：

用户做了什么？
代码执行到了哪里？


记录：

- 点击事件
- 页面跳转
- Intent/Event
- UseCase调用
- Command执行


示例：

[OP][NAV]

from=Home
to=MealEditor


[OP][EVENT]

event=SaveMeal


用途：

定位：

- 点击无响应
- 路由错误
- 事件丢失


---

## 2. UI State Trace 界面状态

目的：

回答：

为什么页面显示成这样？


记录：

- Screen
- State变化
- Loading
- Empty
- Error
- 数据数量


示例：

[UI][STATE]

screen=Home

oldCount=2

newCount=3

reason=MealUpdated


用途：

定位：

- UI不刷新
- 状态覆盖
- Compose状态问题


---

## 3. Data Flow Trace 数据流转

目的：

回答：

数据从哪里来，到哪里去？


记录：

Source:

Database

↓

Repository

↓

Domain Model

↓

Projection

↓

ViewModel

↓

UI


示例：

[DATA][FLOW]

source=MealRecordRepository

model=MealDayContent

projection=DayMealCardData


用途：

定位：

- 数据丢失
- 错误缓存
- Projection错误


---

## 4. Performance Trace

补充能力：

记录：

- SQL耗时
- 网络耗时
- AI耗时
- 图片加载耗时


示例：

[PERF]

operation=LoadMeal

cost=125ms


---

# 四、Logger设计


禁止：

业务代码直接：

Log.d()

统一：

AppLogger


接口：

verbose()
debug()
info()
warn()
error()


参数：

category

event

traceId

key-value


示例：

category=DATA

event=ProjectionBuild

traceId=xxx


---

# 五、日志级别策略


采用Android标准：

VERBOSE

DEBUG

INFO

WARN

ERROR


规则：

配置级别输出：

当前级别以及更高重要级别。


例如：

DEBUG:

DEBUG+
INFO+
WARN+
ERROR


INFO:

INFO+
WARN+
ERROR


ERROR:

ERROR


---

# 六、环境策略


## Debug

默认：

DEBUG级别。

输出：

全部：

- 操作
- UI
- 数据
- 性能


## Release


默认：

ERROR

+ Important Info


输出：

- 崩溃
- 严重异常
- 关键业务状态


不输出：

详细数据流。


---

# 七、TraceId设计


每个用户行为产生TraceId。


例如：

用户保存餐食：

traceId=MEAL_SAVE_001


完整链路：

[OP]

用户点击保存


[DATA]

保存MealRecord


[DATA]

Projection刷新


[UI]

页面更新


最终可以还原一次完整行为。


---

# 八、MDC3应用示例


Meal Lifecycle：

Database Mutation

↓

Revision Token

↓

Repository Flow

↓

MealDayContent

↓

MealDayCardProjector

↓

DayMealCardData

↓

UI


日志：

[MDC3][Revision]

meal_record_dish changed


[MDC3][Projection]

card rebuilt


[MDC3][UI]

state updated


---

# 九、与UBF Blueprint结合


未来每个Blueprint增加：

## Static Evidence

代码：

- Commit
- Diff
- Test


## Runtime Evidence

日志：

- Trace
- Device验证
- Flow


## Architecture Evidence

文档：

- ADR
- Decision


形成：

                Blueprint

                    |

        +-----------+-----------+

        |           |           |

    Static      Runtime     Architecture

    Evidence    Evidence    Evidence


---

# 十、多角色Review要求


## 算法/数据类

Algorithm Engineer：

关注：

- 数据契约
- 算法输入
- 数据质量


Google Quality Engineer：

关注：

- 测试
- 回归
- 边界


Apple Engineer：

关注：

- 生命周期
- 状态管理


## UI类


Apple UX Engineer：

关注：

- 用户心智
- 交互一致性


Google UI Engineer：

关注：

- 平台规范
- 组件


UI Engineer：

关注：

- 实现成本
- 可维护性


ARCH：

最终裁决。


---

# 十一、本地模型使用方式


本地模型拥有：

- 全景图
- 功能地图
- 项目源码


使用本方案：

1. 扫描当前日志缺失点
2. 建立模块Trace地图
3. 对照Blueprint检查边界
4. 提出Observability改造任务


输出：

Current State

↓

Gap Analysis

↓

Blueprint Candidate


---

# 十二、长期目标


最终形成：

代码可读

+

架构可解释

+

运行可追踪

+

问题可复现

+

AI可分析


即：

AI时代的软件工程闭环。
