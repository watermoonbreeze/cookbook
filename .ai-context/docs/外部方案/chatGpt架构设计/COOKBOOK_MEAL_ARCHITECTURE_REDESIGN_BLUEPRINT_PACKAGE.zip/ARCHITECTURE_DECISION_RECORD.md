# Architecture Decision Record

## Decision

撤销之前单一 Meal Aggregate 假设。

原因：

Reality Verification 证明：

当前真实事实来源：

meal_record

同时承担：

-   未来计划
-   当前记录
-   历史查询

因此：

Meal 不是当前唯一领域事实。

## New Direction

拆分业务语义：

MealPlanning Context

MealRecording Context

FoodKnowledge Context

当前不立即拆数据库。

采用演进式架构。

## Decision Status

ARCH DECISION:

PROPOSED

等待 Blueprint Review 后执行。
