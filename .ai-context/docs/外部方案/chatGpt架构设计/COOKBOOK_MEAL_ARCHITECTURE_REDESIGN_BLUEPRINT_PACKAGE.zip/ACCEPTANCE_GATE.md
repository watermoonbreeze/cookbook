# ARCH Acceptance Gate

必须验证：

## Reality Alignment

设计必须能解释：

meal_record

MealRecordRepository

AI commit flow

Timeline

## Boundary

必须不存在：

Planning 和 Recording 混淆。

## Migration

不能破坏：

已有保存流程。

## AI

AI 不绕过 Domain。

## Scope

不允许：

提前拆数据库。
