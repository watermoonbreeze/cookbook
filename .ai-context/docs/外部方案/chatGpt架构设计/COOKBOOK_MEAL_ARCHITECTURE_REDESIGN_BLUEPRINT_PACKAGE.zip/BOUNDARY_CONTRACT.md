# Boundary Contract

## MealPlanning

负责：

-   计划
-   排期
-   未来安排

不负责：

-   实际摄入

## MealRecording

负责：

-   已发生记录
-   历史查询

不负责：

-   生成计划

## FoodKnowledge

负责：

-   Dish
-   Ingredient
-   Nutrition source

不负责：

-   用户当天选择

## AI Boundary

AI 输出：

Suggestion

不是：

MealRecord

不是：

MealPlan

必须经过业务确认。
