# Future Execution Guidance

生成 coder execution package 前必须完成：

1.  Architecture Decision Acceptance
2.  Existing file mapping
3.  Changed-set definition
4.  Migration boundary

Coder 不负责：

-   领域设计
-   状态定义
-   数据库决策

Coder 只执行冻结蓝图。
