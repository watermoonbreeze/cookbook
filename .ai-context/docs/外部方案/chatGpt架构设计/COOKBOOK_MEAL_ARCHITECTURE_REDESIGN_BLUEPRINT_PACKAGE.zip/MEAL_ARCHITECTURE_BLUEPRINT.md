# Meal Architecture Blueprint

## 1. Target Domain Model

目标：

不要强行统一所有 Meal。

建立三个语义边界。

------------------------------------------------------------------------

# MealPlanning

职责：

描述用户未来想吃什么。

核心：

MealPlan

生命周期：

DRAFT

PLANNED

CANCELLED

------------------------------------------------------------------------

# MealRecording

职责：

描述实际发生的饮食记录。

核心：

MealRecord

生命周期：

CREATED

RECORDED

MODIFIED

ARCHIVED

------------------------------------------------------------------------

# FoodKnowledge

职责：

描述可复用知识。

当前对应：

Dish

Ingredient

未来可能：

Recipe

## 2. Relationship

MealPlan

    |

    | optional conversion

    v

MealRecord

注意：

计划不等于记录。

## 3. Current Migration

当前：

meal_record

继续作为存储事实。

新增：

Domain Adapter。

不要立即迁移数据库。
