# Lifecycle Redesign

旧：

DRAFT PLANNED RECORDED ARCHIVED

问题：

计划和记录混合。

新：

## MealPlanning Lifecycle

DRAFT

PLANNED

CANCELLED

## MealRecording Lifecycle

CREATED

RECORDED

MODIFIED

ARCHIVED

## Conversion

MealPlan

↓

User Confirm

↓

MealRecord
