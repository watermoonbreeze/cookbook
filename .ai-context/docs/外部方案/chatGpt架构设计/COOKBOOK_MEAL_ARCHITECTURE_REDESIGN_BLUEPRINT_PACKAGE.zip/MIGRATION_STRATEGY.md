# Migration Strategy

## Phase 1

保持数据库不变。

增加：

Domain Mapping。

## Phase 2

逐步让 UseCase 使用新边界。

## Phase 3

根据实际收益决定是否拆表。

禁止：

一次性数据库重构。

## Risk

最大风险：

重新制造双模型。

所以必须保证：

Adapter 是唯一桥梁。
