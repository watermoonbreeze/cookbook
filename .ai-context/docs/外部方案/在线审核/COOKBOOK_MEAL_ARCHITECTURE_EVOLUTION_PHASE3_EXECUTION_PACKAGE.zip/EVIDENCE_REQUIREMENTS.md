# Evidence Requirements

Provide: - changed files - projection mapping - tests - migrated pages -
remaining legacy reads

Update BLUEPRINT_STATE:

CODE_COMPLETE TURN=REVIEW
