# Phase 3 Projection Migration

## Objective

建立 Domain Projection 边界。

Target:

Storage -\> Repository -\> Domain Projection -\> UI

## Allowed

-   Projection Model
-   Mapping
-   Home/Timeline/History read migration
-   Projection tests

## Forbidden

-   Delete legacy model
-   Database schema change
-   Repository rewrite
-   AI changes
-   Recipe/Nutrition expansion
