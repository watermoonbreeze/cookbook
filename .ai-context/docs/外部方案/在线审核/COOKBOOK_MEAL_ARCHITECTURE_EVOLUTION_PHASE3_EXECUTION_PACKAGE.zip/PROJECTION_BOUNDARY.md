# Projection Boundary

Projection is read model, not domain truth.

Rules: - Domain owns business facts. - Projection serves UI. - UI must
not directly depend on storage entity. - Projection must not mutate
domain state.
