# Target Read Flow

Before:

UI -\> Legacy Model / Repository

After:

UI -\> Projection Model -\> Repository -\> Domain / Adapter

Keep write flow unchanged.
