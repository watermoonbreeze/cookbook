# Migration Strategy

Gradual migration:

Phase A: Add Projection Adapter.

Phase B: Move read entry points.

Phase C: Evaluate legacy cleanup later.

Do not delete legacy now.
