# 00 — SOURCE IDENTITY AND FACTS

## Source identity

- Discovery commit: `6f25028b1e07fe88e64b6e0406f14c062e13b6ae`
- Discovery evidence code base: `7c9a0707ae717b7d5ae3e30221b84e6ea5595bac`
- Evidence artifact bundled at:
  `ARCH_EVIDENCE/MEAL_DATA_CURRENT_STATE_EVIDENCE.zip`

Discovery 只采集事实，不修改产品代码。

## Proven facts

### Persisted truth

当前 Meal 持久化真相来自：

- `meal_type`
- `meal_record`
- `meal_record_dish`

`meal_record` 没有 `plan` / `plan_state` / `is_plan_state` 字段。

### Domain / read / edit models

- `MealRecord`：持久化 meal_record 的领域模型。
- `DayMealCardData`：Home / Timeline / WeekPlan / Search / AddMeal preview 的 read/display projection。
- `MealSection`：Day card 内的餐次 read projection。
- `DayMealDraft`：`saveDayMeals()` 的写入 payload；本身不持久化。
- `MealRecordEditData`：编辑回填 read model；本身不持久化。
- `MealBlockUiState`：Manual editing UI state。
- `AutoGenPreview`：AI preview session state；commit 前不持久化。

### Current temporal semantics

当前 `isPlanState` 不是存储状态：

- today → `plan=false`
- future → `plan=true`
- `loadDayMealCard()` 使用 `date > today` 推导
- Repository private builder 默认使用 `DateTime.today()`

因此“计划”当前只是 future-date 的投影视图语义。

### Current write convergence

Manual:
`MealBlockUiState -> DayMealDraft -> saveDayMeals -> meal_record`

AI:
`AutoGenPreview -> commit -> DayAutoGenerator -> DayMealDraft -> saveDayMeals -> meal_record`

两条写路径已有共同持久化入口，必须保留。

### Current structural risk

`observeTodayPlusFuture()` 当前先取固定上限的 upcoming rows，再按日期 group。
`UPCOMING_ROW_LIMIT=60` 只是经验上限，没有源码层面的“完整日期不会被截断”证明。
本 Blueprint 将消除这个 row-count assumption。
