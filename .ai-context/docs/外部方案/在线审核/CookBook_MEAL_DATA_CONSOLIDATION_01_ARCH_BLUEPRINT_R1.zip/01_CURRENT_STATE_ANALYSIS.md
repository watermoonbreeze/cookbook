# 01 — CURRENT STATE ANALYSIS

## 1. Current layers are semantically mixed

```text
SQL / meal_record
      |
      v
MealRecordRepository
  - SQL access
  - write orchestration
  - date selection
  - temporal classification
  - DayMealCardData construction
  - DishMini enrichment
  - pantry display flags
      |
      +--> Home
      +--> Timeline
      +--> WeekPlan
      +--> Search
      +--> AddMeal
```

Repository 目前既是 persistence gateway，又是 read projection assembler。

本轮只拆“Meal temporal/read semantic boundary”，不处理 Pantry/Nutrition enrichment。

## 2. Persisted truth

`MealRecord` 表示某日某餐次的存储事实。

重要：

未来日期的 `meal_record` 与过去/今天使用同一个持久化结构。
数据库无法也不需要回答“这是 plan 还是 actual”。

因此：

```text
Persisted Meal Truth
!=
Temporal Presentation Meaning
```

## 3. DayMealCardData is projection, not truth

当前字段：

```text
date
isToday
isPlanState
meals
```

问题：

两个 Boolean 可理论上表达非法组合：

```text
isToday=true, isPlanState=true
```

并且不同调用点重复计算日期语义。

目标不是删除该 UI/read model，而是让它只能从单一 temporal role 派生。

## 4. Editing boundary

Manual 已具备正确的两层：

```text
MealBlockUiState
    ↓
DayMealDraft
    ↓
saveDayMeals
```

但 `DayMealDraft` 定义在 Repository 文件尾部，语义容易被误读成 repository implementation detail。

本轮将它抽成独立 boundary contract 文件，但保持 package/signature，避免业务迁移。

## 5. AI boundary

正确事实：

```text
INPUT
→ GENERATING
→ PARTIAL_READY / PREVIEW_READY
→ SAVING
→ DONE
```

只有：

`confirmSave -> commit -> DayAutoGenerator.commit -> saveDayMeals`

完成后才成为 persisted truth。

`AutoGenPreview`、`DONE` 都不进入数据库。

本轮冻结此架构，不重新设计 AI state machine。

## 6. Timeline / Home / AddMeal duplication

- Repository builder 计算 `isToday/isPlanState`
- AddMeal preview 又自行计算
- Home 依赖 Repository 已投影结果
- Timeline 依赖 Repository 已投影结果

本轮要把“date relative to referenceDate”的含义集中成 pure projector。
