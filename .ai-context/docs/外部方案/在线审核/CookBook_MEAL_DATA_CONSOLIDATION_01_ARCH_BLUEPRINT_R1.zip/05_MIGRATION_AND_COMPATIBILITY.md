# 05 — MIGRATION AND COMPATIBILITY

## 1. Zero user-visible behavior change

This is architecture migration.

Expected UI before == after for:

- Home today/future cards
- Timeline cards/calendar
- Manual plan preview
- WeekPlan card visuals
- Search card visuals
- AI preview/save
- existing-meal guard

## 2. Compatibility strategy

`DayMealCardData.isToday` and `isPlanState` stay readable so existing UI does not need broad rewrite.

Difference:

Before:
two mutable constructor truths

After:
two derived compatibility views of one enum truth.

## 3. API staging

New neutral APIs are authoritative for:

- Home
- Timeline

Legacy card-returning Repository APIs may stay for other features in R1.

They must internally use the same projector.

Do not remove public methods unless full repo grep proves zero callers and tests remain green.

## 4. No MealPlan migration

Future dates stay in `meal_record`.

No historical rows are transformed.

No migration file.

## 5. No AI migration

AI contract remains:

`AutoGenPreview -> commit -> DayMealDraft -> saveDayMeals`

Do not convert AutoGenPreview into MealDayContent as persistence truth.
Preview UI may continue using its own preview model.

## 6. No fake Snapshot entity

`snapshotDay()` is an undo restore payload built from `DayMealDraft`.

Do not create a new persisted `MealSnapshot` concept in this batch.

## 7. Out of scope / later candidates

Not authorized in R1:

- splitting `MealRecordRepository` into read/write repositories
- pantry projection separation
- nutrition projection separation
- midnight live rollover architecture
- Search-specific query redesign
- WeekPlan redesign
- actual-vs-plan dual persistence
- sync/import/export meal semantics

These may be future Blueprints only after R1 evidence.
