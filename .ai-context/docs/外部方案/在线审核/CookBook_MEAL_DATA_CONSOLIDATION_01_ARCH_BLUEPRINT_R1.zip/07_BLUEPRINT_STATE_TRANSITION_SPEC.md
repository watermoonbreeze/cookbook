# 07 — BLUEPRINT_STATE TRANSITION SPEC

Canonical:
`.ai-context/docs/context_memory/BLUEPRINT_STATE.md`

## P0 — before code

Current expected:

```text
MEAL-DATA-CONSOLIDATION-01
PREVIEW
TURN=REVIEW
Holder=ARCH
```

Persist this ARCH decision as:

```text
Batch: MEAL-DATA-CONSOLIDATION-01
Revision: ARCH_BLUEPRINT_R1
State: BLUEPRINT_READY / CODE
TURN: CODE
Holder: CODER
ARCH discovery commit: 6f25028b1e07fe88e64b6e0406f14c062e13b6ae
Evidence code base: 7c9a0707ae717b7d5ae3e30221b84e6ea5595bac
Scope:
  A Semantic Boundary
  B Repository Neutralization
  C Home/Timeline/Manual Preview migration
  D tests/evidence/feature sync
Prohibitions:
  no MealPlan persistence
  no schema migration
  no user behavior change
```

P0 commit + push.
Do not wait for ARCH review; continue CODE.

## P1 — after code

Do not write ACCEPT.

Final handoff:

```text
State: CODE_COMPLETE / PENDING ARCH REVIEW
TURN: REVIEW
Holder: ARCH
delivery head: <actual hash>
automated gates: <actual results>
device evidence: PASS or explicit PENDING_DEVICE_VERIFICATION
changed set: <exact>
feature sync: <actual canonical result>
next: external ARCH review
```

Keep historical Preview as historical/non-current only.
Never create two current Truth blocks.
