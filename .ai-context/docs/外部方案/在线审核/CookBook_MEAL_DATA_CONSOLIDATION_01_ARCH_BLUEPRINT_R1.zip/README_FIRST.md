# README_FIRST — MEAL-DATA-CONSOLIDATION-01 / ARCH BLUEPRINT R1

## 0. Authority

本包是 `MEAL-DATA-CONSOLIDATION-01` 的正式 ARCH Blueprint + 一次性 CODE 执行包。

- Discovery commit: `6f25028b1e07fe88e64b6e0406f14c062e13b6ae`
- Evidence code base recorded by Discovery: `7c9a0707ae717b7d5ae3e30221b84e6ea5595bac`
- 当前治理起点：`PREVIEW / TURN=REVIEW / Holder=ARCH`
- 本包 AUTHORITATIVE ARCH DECISION 优先于 coder 自己的重构偏好。
- 不需要聊天中的补充说明；本 README 是唯一入口。

## 1. 执行模式

一次执行、一次 ARCH 总审核。禁止每完成一个子项就停下来等审核。

顺序：

P0. ARCH Blueprint Persistence
→ A. Semantic Boundary
→ B. Repository Neutralization
→ C. Home / Timeline / Manual Preview Migration
→ D. Tests / Evidence / Feature Sync
→ P1. ARCH Handoff Persistence
→ commit + push
→ `TURN=REVIEW`

P0 persistence commit push 后不等待 ARCH，直接继续 A→B→C→D。

## 2. 本轮根本目标

不是“大重构 Meal”。

本轮只完成：

1. 把 Persisted Truth、Editing Draft、AI Preview、Read Projection 明确分层。
2. 明确：未来日期餐食不是独立 `MealPlan` 持久化实体。
3. 消除 `DayMealCardData(isToday, isPlanState)` 可表达矛盾状态的问题。
4. 把日期相对语义集中到一个纯 projector。
5. Repository 先形成“中性日内容 → UI 投影”的 seam；本轮不拆成多个 Repository。
6. Home / Timeline / Manual Preview 三条主链改用同一语义投影。
7. 修掉 Home `UPCOMING_ROW_LIMIT` 依赖“行数足够代表完整日期”的结构性风险。

## 3. 严禁

- 禁止新增 `MealPlan` table/entity/plan_state/is_plan_state 持久字段。
- 禁止数据库 schema/table/column migration。
- 允许新增/修改纯 SELECT query，但不得改 schema。
- 禁止修改用户业务规则。
- 禁止改变 AI merge/replace/append 语义。
- 禁止改变 existing-meal guard。
- 禁止改变页面导航、UI 布局、视觉。
- 禁止把 `AutoGenPreview`、`MealBlockUiState`、`DayMealDraft` 落库。
- 禁止把 `DONE` 当数据库状态。
- 禁止顺手拆 `MealRecordRepository` 为多个 repository。
- 禁止顺手重构 Pantry/Nutrition/Search/WeekPlan 业务。
- 禁止自行宣布 ACCEPT/ACCEPTED。

## 4. 必读顺序

1. `00_SOURCE_IDENTITY_AND_FACTS.md`
2. `01_CURRENT_STATE_ANALYSIS.md`
3. `02_ARCH_DECISION_RECORD.md`
4. `03_TARGET_ARCHITECTURE.md`
5. `04_CODE_EXECUTION_BLUEPRINT.md`
6. `05_MIGRATION_AND_COMPATIBILITY.md`
7. `06_TEST_EVIDENCE_ACCEPTANCE.md`
8. `07_BLUEPRINT_STATE_TRANSITION_SPEC.md`
9. `08_EXECUTION_CONTRACT.md`
10. `machine/turn_contract.json`

## 5. STOP 条件

仅以下情况 STOP：

- 远程 canonical head 已不再包含 Discovery commit 的连续性；
- 当前源码事实与随包 evidence 出现会改变 ARCH 决策的实质冲突；
- exact symbol search 发现本包预计修改会破坏未列明的重要调用契约，且无法按兼容策略机械处理；
- 无法建立安全隔离执行环境；
- changed set 无法收敛到授权范围；
- 自动测试证明本包规定的不变量无法同时成立。

宿主工作区 dirty 本身不是 STOP；使用隔离 worktree。

STOP 也必须把原因和 evidence 写入可 push 治理文档并 push。
