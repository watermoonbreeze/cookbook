# 06 — TEST / EVIDENCE / ACCEPTANCE

## Hard invariants

### INV-MDC-01 Persisted Truth
No new table/column/status for plan semantics.

### INV-MDC-02 Temporal uniqueness
Every DayMealCardData has exactly one:
PAST / TODAY / FUTURE.

### INV-MDC-03 Compatibility
- TODAY => `isToday=true`, `isPlanState=false`
- FUTURE => `isToday=false`, `isPlanState=true`
- PAST => both false

### INV-MDC-04 Explicit time reference
Pure projector has no `DateTime.today()` call.

### INV-MDC-05 Neutral content
`MealDayContent` contains no today/plan state.

### INV-MDC-06 Manual write boundary
Manual save still reaches `saveDayMeals()` using `DayMealDraft`.

### INV-MDC-07 AI write boundary
AI commit still reaches `saveDayMeals()`; preview remains non-persisted.

### INV-MDC-08 Home complete days
A date is never truncated because it has too many meal_record rows.

### INV-MDC-09 Home selection
With today present:
today + earliest two future dates.

Without today:
earliest two future dates.

### INV-MDC-10 Timeline
Timeline date set continues to come from actual recorded dates.

### INV-MDC-11 Existing meal guard
Existing-date reject/merge behavior unchanged.

### INV-MDC-12 UI contract
No navigation/layout/copy behavior changed by this batch.

### INV-MDC-13 Single projector
No duplicate date→today/future boolean algorithm remains in main migrated paths.

---

## Required tests

### T-MDC-01 Temporal projector
Test PAST / TODAY / FUTURE.

### T-MDC-02 Compatibility getters
Assert all three truth table combinations above.

### T-MDC-03 Home today present
Seed today + 3 future dates.
Result = today + first 2 future.

### T-MDC-04 Home today absent
Seed 3 future dates.
Result = first 2 future.

### T-MDC-05 Home date completeness stress
Seed one selected date with >60 meal_record rows (or otherwise exceed old row assumption).
Assert all records/meal sections for selected date are present.
This test proves removal of `UPCOMING_ROW_LIMIT` correctness dependency.

### T-MDC-06 Neutral-to-card parity
For fixed `referenceDate`, project neutral content and assert date/meals + old visible flags match expected behavior.

### T-MDC-07 Timeline neutral parity
Seed multiple recorded dates.
`loadMealDayContentsByDates()` returns same dates/meal contents/order contract as previous timeline card path.

### T-MDC-08 Manual save regression
Existing AddMeal/Repository test suite remains green.

### T-MDC-09 AI regression
Existing AI preview/commit tests remain green; no production AI state machine edit expected.

---

## Build gates

Required:

- `:shared:testDebugUnitTest`
- `:androidApp:testDebugUnitTest`
- `:androidApp:assembleDebug`

If project has canonical script wrappers, use them in addition, not instead.

---

## Static gates

Evidence file must include outputs of:

```text
git grep "DayMealCardData("
git grep "isPlanState ="
git grep "isToday ="
git grep "UPCOMING_ROW_LIMIT"
git diff --name-only <base>..<delivery>
```

Acceptance expectation:

- no old constructor writes of independent isToday/isPlanState remain
- `UPCOMING_ROW_LIMIT` is gone from Home completeness logic
- no plan persistence field/table added

---

## Device smoke

Because no intentional UI behavior changes, device smoke is regression evidence, not a license to alter UI.

Register:

- E-MDC-01 Home today/future looks unchanged
- E-MDC-02 Timeline card/calendar navigation unchanged
- E-MDC-03 Single Manual future preview still shows plan styling and saves
- E-MDC-04 AI preview/save still completes

If no device:
`PENDING_DEVICE_VERIFICATION`
with exact reason.
Do not fake PASS.

Automated acceptance may be returned to ARCH with device smoke pending, explicitly marked.
