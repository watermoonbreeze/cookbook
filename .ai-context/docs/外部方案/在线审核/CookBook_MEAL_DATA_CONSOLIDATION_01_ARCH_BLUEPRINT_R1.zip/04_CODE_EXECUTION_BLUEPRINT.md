# 04 — CODE EXECUTION BLUEPRINT

## Workstream A — Semantic Boundary

### A1. Split model file by semantic role

Modify:
`shared/src/commonMain/kotlin/com/sxdbsm/cookbook/domain/model/MealRecord.kt`

Keep only persisted-oriented:

- `MealType`
- `MealRecord`

Create:
`shared/src/commonMain/kotlin/com/sxdbsm/cookbook/domain/model/MealDayModels.kt`

Move without semantic loss:

- `MealSection`
- `DayMealCardData`

Add:

- `MealDayContent`
- `MealDayTemporalRole`

### A2. DayMealCardData canonical shape

Target:

```kotlin
data class DayMealCardData(
    val date: LocalDate,
    val temporalRole: MealDayTemporalRole,
    val meals: List<MealSection>,
) {
    val isToday: Boolean
        get() = temporalRole == MealDayTemporalRole.TODAY

    val isPlanState: Boolean
        get() = temporalRole == MealDayTemporalRole.FUTURE
}
```

Do not retain independently writable boolean state.

### A3. Pure projector

Create:
`shared/src/commonMain/kotlin/com/sxdbsm/cookbook/domain/projection/MealDayCardProjector.kt`

Required pure API shape (equivalent naming accepted only if manifest documents exact name):

```kotlin
object MealDayCardProjector {
    fun temporalRole(date: LocalDate, referenceDate: LocalDate): MealDayTemporalRole

    fun project(
        content: MealDayContent,
        referenceDate: LocalDate,
    ): DayMealCardData
}
```

No clock/database/repository access.

### A4. Extract repository contracts

Create:
`shared/src/commonMain/kotlin/com/sxdbsm/cookbook/data/repository/MealRecordContracts.kt`

Move, same package:

- `DayMealDraft`
- `MealRecordEditData`

Delete their old definitions from `MealRecordRepository.kt`.

No field rename.

---

## Workstream B — Repository Neutralization

Modify:
`MealRecordRepository.kt`

### B1. Neutral builder

Replace temporal-aware private assembly with neutral assembly:

```text
DB rows
→ MealSection list
→ MealDayContent(date, meals)
```

Required private or internal seam:

`buildMealDayContent(...)`

It must not call `DateTime.today()`.

### B2. Compatibility projection

Any remaining Repository API returning `DayMealCardData` must:

1. obtain/build `MealDayContent`
2. call `MealDayCardProjector`

Do not duplicate:

`date == today`
or
`date > today`

inside multiple builders.

### B3. Neutral Timeline API

Add:

```kotlin
suspend fun loadMealDayContentsByDates(
    dates: List<LocalDate>
): List<MealDayContent>
```

(or semantically equivalent exact API documented in execution report).

Existing `loadTimelineCardsByDates` may remain compatibility wrapper.

### B4. Neutral Home API

Add a neutral API with semantics:

```kotlin
fun observeUpcomingMealDayContents(
    referenceDate: LocalDate,
    futureDayLimit: Int = 2,
): Flow<List<MealDayContent>>
```

Name may vary only if behavior is exact.

### B5. Remove row-count completeness assumption

Modify `Cookbook.sq` with a READ-ONLY query such as:

```sql
selectUpcomingMealDates:
SELECT DISTINCT date
FROM meal_record
WHERE status = 1
  AND date >= ?
ORDER BY date ASC
LIMIT ?;
```

No schema change.

Repository observes date keys, selects required 0/1 today + max 2 future dates, then uses `selectMealRecordsByDates` to fetch complete rows.

Remove `UPCOMING_ROW_LIMIT` if no longer used.

### B6. Preserve dish enrichment

Current `buildDishesByMealRecord` / pantry flags are out of scope.

Do not rewrite them.

---

## Workstream C — Main Feature Migration

### C1. Home

Modify:
`androidApp/.../ui/home/HomeViewModel.kt`

Change main feed from pre-projected repository output to:

```text
observeUpcomingMealDayContents(referenceDate)
→ MealDayCardProjector.project(each, referenceDate)
→ HomeUiState
```

Use one explicit captured `referenceDate` matching current behavior.

`HomeScreen.kt` must not require product-behavior modification.

### C2. Timeline

Modify:
`androidApp/.../ui/timeline/TimelineViewModel.kt`

Visible dates remain selected exactly as today.

Load neutral contents:

`loadMealDayContentsByDates`

Then project each with one explicit reference date.

Preserve date ordering and page behavior.

### C3. Manual AddMeal Preview

Modify:
`AddDayFoodScreen.kt`

Current preview currently constructs `DayMealCardData` directly with booleans.

Change to:

1. create `MealDayContent(date, meals)`
2. call `MealDayCardProjector.project(content, referenceDate)`

Do not change save button copy or `state.isPlan` workflow behavior.

### C4. Remaining consumers

Before edit, run full repo:

- `git grep "DayMealCardData("`
- `git grep "isPlanState ="`
- `git grep "isToday ="`

If additional constructors exist outside evidence snapshot, convert them mechanically to projector/temporalRole without changing business behavior.

Consumers that only READ `isToday`/`isPlanState` require no semantic change because compatibility getters remain.

---

## Workstream D — Governance / Feature Sync

Run canonical feature impact detection.

Expected affected features at minimum:

- F-MEAL
- F-TIMELINE

F-TOOLS only if repository's canonical sync rules classify the shared projector/model as that feature; do not force it manually.

Update feature implementation docs only with facts actually delivered.

No ACCEPT.
