# 08 — EXECUTION CONTRACT

## Actor sequence

1. `ARCH_PERSISTENCE_EXECUTOR`
2. `CODER`
3. `ARCH_HANDOFF_PERSISTENCE_EXECUTOR`

## ARCH_PERSISTENCE_EXECUTOR

Mechanical only.

Must:
- persist this Blueprint
- switch canonical TURN REVIEW→CODE
- commit + push

Must not:
- change ADRs
- rename scope
- add/remove invariants

## CODER

Implement exactly A+B+C+D.

Allowed reasoning:
- mechanical adaptation to actual symbol locations
- compatibility fixes required by compiler/tests
- exact query syntax required by SQLDelight

Not allowed:
- introduce new product semantics
- create plan persistence
- split repository architecture beyond Blueprint
- redesign UI

## ARCH_HANDOFF_PERSISTENCE_EXECUTOR

After gates:
- record evidence
- set CODE_COMPLETE / PENDING ARCH REVIEW
- TURN=REVIEW
- commit + push

## Failure / STOP evidence

Even on STOP, write:

- stop code
- exact failing invariant/gate
- command/output excerpt
- current changed set
- commit if governance rules allow
- push the evidence artifact

No silent local-only STOP.
