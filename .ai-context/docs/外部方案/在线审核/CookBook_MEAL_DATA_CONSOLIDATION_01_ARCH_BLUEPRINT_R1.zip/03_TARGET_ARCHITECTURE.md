# 03 — TARGET ARCHITECTURE

## 1. Target layering

```text
┌──────────────────────────────┐
│ Persisted Meal Truth         │
│ meal_record / relation rows  │
└──────────────┬───────────────┘
               │
               v
┌──────────────────────────────┐
│ MealRecordRepository         │
│ persistence + neutral query  │
└──────────────┬───────────────┘
               │
               v
┌──────────────────────────────┐
│ MealDayContent               │
│ date + meals                 │
│ NO today / plan semantics    │
└──────────────┬───────────────┘
               │ explicit referenceDate
               v
┌──────────────────────────────┐
│ MealDayCardProjector         │
│ PAST / TODAY / FUTURE        │
└──────────────┬───────────────┘
               │
               v
┌──────────────────────────────┐
│ DayMealCardData              │
│ existing UI/read projection  │
└──────────────┬───────────────┘
               │
     ┌─────────┼─────────┐
     v         v         v
    Home    Timeline   AddMeal Preview
```

## 2. Write side remains converged

```text
Manual UI
MealBlockUiState
      |
      v
DayMealDraft
      |
      +------------------+
                         |
AI AutoGenPreview        |
      |                  |
DayAutoGenerator         |
      |                  |
      +--> DayMealDraft -+
                         |
                         v
                  saveDayMeals()
                         |
                         v
                  Persisted Truth
```

## 3. Temporal role contract

Given:

```text
date < referenceDate  => PAST
date = referenceDate  => TODAY
date > referenceDate  => FUTURE
```

UI compatibility:

```text
TODAY  -> isToday=true,  isPlanState=false
FUTURE -> isToday=false, isPlanState=true
PAST   -> isToday=false, isPlanState=false
```

No other combination is representable.

## 4. Home query contract

Home read contract:

```text
optional reference-date content
+
at most 2 earliest future dates with records
```

Every returned day must contain ALL records for that date.

Algorithm:

1. observe upcoming distinct date keys from `referenceDate`
2. if referenceDate exists:
   desired = referenceDate + first 2 future
3. else:
   desired = first 2 future
4. fetch all meal_record rows for desired dates
5. assemble `MealDayContent`
6. HomeViewModel projects with explicit `referenceDate`

Do not use “take N rows then assume full dates”.

## 5. Timeline contract

Timeline continues to define which actual recorded dates are visible.

Repository returns neutral contents for those selected dates.
TimelineViewModel applies `MealDayCardProjector`.

Calendar date truth remains `observeTimelineDates()`.

## 6. Manual preview contract

AddMeal preview must not manually set:

- isToday
- isPlanState

It builds `MealDayContent` from current draft and calls the same projector.

The existing `AddMealUiState.isPlan` may remain for existing button copy / workflow compatibility in this batch, but it is NOT a new domain truth and must not be used as projector input.

## 7. Compatibility boundary

Legacy APIs returning `DayMealCardData` may remain temporarily for WeekPlan/Search/other call sites.

They must delegate through:

`MealDayContent -> MealDayCardProjector`

No second temporal algorithm may remain.
