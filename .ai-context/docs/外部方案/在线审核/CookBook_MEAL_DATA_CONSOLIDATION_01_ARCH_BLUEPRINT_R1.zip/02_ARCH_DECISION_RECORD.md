# 02 — ARCH DECISION RECORD

## ADR-MDC-01 — Persisted Truth 不变

**ACCEPTED**

Meal persisted truth 继续使用当前：

- `meal_record`
- `meal_record_dish`
- `meal_type`

本轮没有 schema migration。

## ADR-MDC-02 — 不创建 MealPlan 持久化实体

**ACCEPTED**

当前产品的“未来计划”是：

```text
future-dated meal_record
+ temporal projection
```

不是单独存储的 plan。

本轮禁止引入：

- MealPlan table
- plan_state
- is_plan_state persistence
- actual/plan 双表

未来若产品出现“同一天同时存在计划与实际、且二者要独立保留”的新业务需求，再启动独立 Blueprint。

## ADR-MDC-03 — Temporal Role 替代双 Boolean 作为唯一分类真相

新增：

```kotlin
enum class MealDayTemporalRole {
    PAST,
    TODAY,
    FUTURE,
}
```

`DayMealCardData` 的 canonical constructor 使用：

```kotlin
val temporalRole: MealDayTemporalRole
```

兼容属性：

```kotlin
val isToday: Boolean get() = temporalRole == TODAY
val isPlanState: Boolean get() = temporalRole == FUTURE
```

不允许再把 `isToday` / `isPlanState` 作为独立可写 constructor state。

## ADR-MDC-04 — Explicit reference date

Temporal classification 必须是纯函数：

```kotlin
roleFor(date, referenceDate)
```

禁止在 pure projector 内调用 `DateTime.today()`。

“today”由 feature/application boundary 显式传入。

## ADR-MDC-05 — 引入 MealDayContent 中性 Read Model

新增：

```kotlin
data class MealDayContent(
    val date: LocalDate,
    val meals: List<MealSection>,
)
```

它代表：

“某日期查询出来、已组装好的餐食内容”

它：

- 不是 persisted entity
- 不包含 today/future 语义
- 不包含 plan Boolean
- 可被多个 feature 投影

注意：`DishMini` 当前仍含现有 enrichment，本轮不拆 Pantry/Nutrition。

## ADR-MDC-06 — DayMealCardData 保留为 UI/read projection

本轮不把所有 UI 改成新模型。

使用：

```text
MealDayContent
    ↓ MealDayCardProjector(referenceDate)
DayMealCardData
    ↓
existing UI
```

从而用户界面保持不变。

## ADR-MDC-07 — Repository 本轮不拆类

`MealRecordRepository` 继续作为 persistence gateway。

但内部职责分成：

1. SQL / record access
2. neutral MealDayContent assembly
3. compatibility API delegation

Temporal classification 移出 Repository private builder，进入 pure projector。

这是渐进迁移 seam，不进行一次性 Repository 拆分。

## ADR-MDC-08 — DayMealDraft 正式定义为 Write Contract

`DayMealDraft` 不改字段、不改语义。

从 `MealRecordRepository.kt` 尾部移到独立：

`data/repository/MealRecordContracts.kt`

同 package，避免 import churn。

KDoc 必须声明：

- non-persisted write command
- Manual / AI / undo restore 共用
- 成为 persisted truth 的时点是 `saveDayMeals()` transaction

`MealRecordEditData` 同文件，声明为 edit read projection。

## ADR-MDC-09 — Home 完整日期不得依赖 row limit

当前 `UPCOMING_ROW_LIMIT` 结构风险必须消除。

允许在 SQLDelight 增加纯 SELECT：

`selectUpcomingMealDates`

但：

- 不新增表
- 不新增列
- 不做 migration

Home 先选 date keys，再批量取完整日期 records。

## ADR-MDC-10 — AI 生命周期冻结

不得修改：

- MergeMode
- hasExisting
- confirmation semantics
- preview/commit 两阶段
- AiMealPhase

本轮只验证 AI 写入仍收敛到 `saveDayMeals()`。
